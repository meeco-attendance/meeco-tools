self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "f961142f52f90f98c5db2d4f6c2d3159",
    "url": "/index.html"
  },
  {
    "revision": "3ce04ae51093e2ffa1c5",
    "url": "/static/css/main.3ae40206.chunk.css"
  },
  {
    "revision": "4b2a21747ab01ff3d5b7",
    "url": "/static/js/2.b951e8e6.chunk.js"
  },
  {
    "revision": "216e537bacc64f9dbaabd26649a9ab95",
    "url": "/static/js/2.b951e8e6.chunk.js.LICENSE.txt"
  },
  {
    "revision": "3ce04ae51093e2ffa1c5",
    "url": "/static/js/main.13890c61.chunk.js"
  },
  {
    "revision": "d114dec1d48b86f8bcfa",
    "url": "/static/js/runtime-main.2df63db6.js"
  }
]);